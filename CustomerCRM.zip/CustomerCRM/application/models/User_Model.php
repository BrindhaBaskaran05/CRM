<?php
	class User_Model extends CI_Model{
		

		public function login($username, $Password){
			//Validate
			$this->db->where('username', $username);
			$this->db->where('password', $Password);

			$result = $this->db->get('tm_user');

			if ($result->num_rows() == 1) {
				return $result->row(0);
			}else{
				return false;
			}
		}

	
		
	}