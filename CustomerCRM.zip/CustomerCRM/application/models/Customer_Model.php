<?php
	class Customer_Model extends CI_Model
	{
		public function __construct()
		{
			$this->load->database();
		}
		public function clear_data($data) {
			$this->db->update('crm_customer', $data);
			return true;
		}
		
		public function Update_Customer($data){
			$query = $this->db->update_batch('crm_customer',$data,'account_number');
		}
		public function Update_Customer_tmp($data){
			$query = $this->db->update_batch('temp_customer',$data,'account_number');
		}

		public function insert_Customer($data){
			$this->db->insert_batch('temp_customer', $data); 
		}
		public function Delete_temp(){
			$this->db->truncate('temp_customer');

		}
		function get_error_log(){
 
			$response = array();
		 
			// Select record
			$this->db->select(' `account_number`, `zone`, `province`,  `log`');
			$this->db->where('error','1');
			$q = $this->db->get('temp_customer');
			$response = $q->result_array();
		 
			return $response;
		  }
		
		

		public function get_customers(){
			$this->db->order_by('customer_id');
			$query = $this->db->get('customer');
			return $query->result_array();
		}
		public function get_customers_temp(){
			$this->db->order_by('id');
			$query = $this->db->get('temp_customer table');
			return $query->result_array();
		}
		
		
		public function getZone($ZoneName){
			
			$this->db->where('zone_description',$ZoneName);
			$this->db->limit(1,0);
			$this->db->select('zone_id');
			$query = $this->db->get('crm_ik_zone');
			//echo $this->db->last_query();
			return $query->result_array();
		}
		public function getProvince($ProvinceName){
			
			$this->db->where('province_description',$ProvinceName);
			$this->db->limit(1,0);
			$this->db->select('province_id');
			$query = $this->db->get('crm_province');
			//echo $this->db->last_query();
			return $query->result_array();
		}

	}