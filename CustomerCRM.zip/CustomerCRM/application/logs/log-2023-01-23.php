ERROR - 2023-01-23 10:48:16 --> Severity: Warning --> fopen(./upload/20230123104816Log_20230123 (4).csv): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 66
ERROR - 2023-01-23 10:48:16 --> Severity: error --> Exception: fgetcsv(): Argument #1 ($stream) must be of type resource, bool given C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 71
ERROR - 2023-01-23 10:48:16 --> Severity: Warning --> include(C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 219
ERROR - 2023-01-23 10:48:16 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 219
ERROR - 2023-01-23 10:52:49 --> Severity: Warning --> Undefined array key "file" C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 34
ERROR - 2023-01-23 10:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 34
ERROR - 2023-01-23 10:52:49 --> Severity: Warning --> Undefined array key "file" C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 37
ERROR - 2023-01-23 10:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 37
ERROR - 2023-01-23 10:52:49 --> Severity: Warning --> Undefined array key "file" C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 40
ERROR - 2023-01-23 10:52:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 40
ERROR - 2023-01-23 10:52:49 --> Severity: Warning --> Undefined array key "extension" C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 41
ERROR - 2023-01-23 10:59:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Team_Model C:\xampp\htdocs\CustomerCRM\system\core\Loader.php 344
ERROR - 2023-01-23 10:59:28 --> Severity: Warning --> include(C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 219
ERROR - 2023-01-23 10:59:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 219
ERROR - 2023-01-23 11:08:35 --> Severity: error --> Exception: unlink(): Argument #1 ($filename) must be of type string, resource given C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 88
ERROR - 2023-01-23 11:08:35 --> Severity: Warning --> include(C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 219
ERROR - 2023-01-23 11:08:35 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 219
ERROR - 2023-01-23 11:08:52 --> Severity: error --> Exception: unlink(): Argument #1 ($filename) must be of type string, resource given C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 88
ERROR - 2023-01-23 11:08:52 --> Severity: Warning --> include(C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 219
ERROR - 2023-01-23 11:08:52 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 219
ERROR - 2023-01-23 11:28:26 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 27
ERROR - 2023-01-23 11:28:26 --> Severity: Warning --> Undefined property: stdClass::$email C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 29
ERROR - 2023-01-23 11:33:23 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 27
ERROR - 2023-01-23 11:33:23 --> Severity: Warning --> Undefined property: stdClass::$email C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 29
ERROR - 2023-01-23 11:33:23 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 27
ERROR - 2023-01-23 11:33:23 --> Severity: Warning --> Undefined property: stdClass::$email C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 29
ERROR - 2023-01-23 11:45:59 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 27
ERROR - 2023-01-23 11:45:59 --> Severity: Warning --> Undefined property: stdClass::$email C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 29
ERROR - 2023-01-23 11:46:30 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 27
ERROR - 2023-01-23 11:46:30 --> Severity: Warning --> Undefined property: stdClass::$email C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 29
ERROR - 2023-01-23 12:36:05 --> 404 Page Not Found: Customer/create
ERROR - 2023-01-23 12:36:05 --> Severity: Warning --> include(C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 182
ERROR - 2023-01-23 12:36:05 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 182
ERROR - 2023-01-23 12:36:18 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 27
ERROR - 2023-01-23 12:36:18 --> Severity: Warning --> Undefined property: stdClass::$email C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 29
ERROR - 2023-01-23 12:36:23 --> 404 Page Not Found: Customer/create
ERROR - 2023-01-23 12:36:23 --> Severity: Warning --> include(C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 182
ERROR - 2023-01-23 12:36:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 182
ERROR - 2023-01-23 12:36:26 --> 404 Page Not Found: Customer/create
ERROR - 2023-01-23 12:36:26 --> Severity: Warning --> include(C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 182
ERROR - 2023-01-23 12:36:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 182
ERROR - 2023-01-23 12:36:36 --> 404 Page Not Found: Customer/create
ERROR - 2023-01-23 12:36:36 --> Severity: Warning --> include(C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 182
ERROR - 2023-01-23 12:36:36 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\CustomerCRM\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\CustomerCRM\system\core\Exceptions.php 182
ERROR - 2023-01-23 12:38:44 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\CustomerCRM\application\controllers\Customer.php 168
ERROR - 2023-01-23 12:43:40 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 27
ERROR - 2023-01-23 12:43:40 --> Severity: Warning --> Undefined property: stdClass::$email C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 29
ERROR - 2023-01-23 13:13:00 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 27
ERROR - 2023-01-23 13:13:00 --> Severity: Warning --> Undefined property: stdClass::$email C:\xampp\htdocs\CustomerCRM\application\controllers\Users.php 29
