<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//user routes




$route['customer'] = 'customer/index';
$route['customer/add'] = 'customer/create';
$route['customer/create'] = 'customer/create';




$route['(:any)'] = 'pages/view/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['default_controller'] = 'Users/login';









