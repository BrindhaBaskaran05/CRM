<?php
	class Customer extends CI_Controller
	{
		public function cleardata(){
			$data['province_id']=0;
			$data['zone_id']=0;
			$usersData = $this->Customer_Model->clear_data($data);
			redirect('customer');
		}
		public function errorlog(){
			// file name 
			$filename = 'Log_'.date('Ymd').'.csv'; 
			header("Content-Description: File Transfer"); 
			header("Content-Disposition: attachment; filename=$filename"); 
			header("Content-Type: application/csv; ");
			
			// get data 
			$usersData = $this->Customer_Model->get_error_log();
		 
			// file creation 
			$file = fopen('php://output', 'w');
		  
			$header = array("Account Number","Zone","Province","Message"); 
			fputcsv($file, $header);
			foreach ($usersData as $key=>$line){ 
			  fputcsv($file,$line); 
			}
			fclose($file); 
			exit; 
		}
		public function import()
		{
//var_dump($_POST);exit();
$filename = $_FILES['file']['name'];

/* Getting File size */
$filesize = $_FILES['file']['size'];


$path_parts = pathinfo($_FILES["file"]["name"]);
$extension = $path_parts['extension'];


/* Location */
$location = "".date("Ymdhis").".".$extension;

$return_arr = array();

/* Upload file */

	$data = array(); 
	//move_uploaded_file($_FILES['file']['tmp_name'],$location);
	  // Set preference 

	  // Load upload library 
	  $config['upload_path']          = './upload/';
                $config['allowed_types']        = 'csv';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
				$config['file_name'] =$location;
				$this->load->library('upload', $config);

                if ( $this->upload->do_upload('file')){
				
		 // Get data about the file
		 $uploadData = $this->upload->data(); 
		 $filename = $uploadData['file_name'];

		 // Reading file
		 $file = fopen('./upload/'.$location,"r");
		 $i = 0;
		 
		 $this->Customer_Model->Delete_temp();

		 while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
			if($i>0){
				$data[] = array(
					'account_number' => $filedata[0],
					'zone' => $filedata[1],
					'province' => $filedata[2]
				   );
				}
			
				$i++;
			 }
			 fclose($file);
			 unlink('./upload/'.$location);
			 $this->Customer_Model->insert_Customer($data);

			 $CustDet = $this->Customer_Model->get_customers_temp();
			 $UpdateCnt=0;
			 $ErrorCnt=0;
			 foreach($CustDet as $Customer){
				$Error=0;
				$Errmsg='';
				$ZoneSpl=explode("-",$Customer['zone']);
				$ZoneDet=$this->Customer_Model->getZone($ZoneSpl[0]);
				if(sizeof($ZoneDet)>0){
					$ZoneId=$ZoneDet[0]['zone_id'];
				}else{
					
					$Error=1;
					$Errmsg.="Invalid Zone Name;";
				}
				$ProvinceSpl=explode("-",$Customer['province']);
				$ProvinceDet=$this->Customer_Model->getProvince($ProvinceSpl[0]);
				if(sizeof($ProvinceDet)>0){
					$ProvinceId=$ProvinceDet[0]['province_id'];
				}else{
					$Error=1;
					$Errmsg.="Invalid Province Name;";
				}
				//$ProvinceName=$this->Customer_Model->CheckDuplicate($this->input->post('TeamName'));
				
				if($Error==1){
					$ErrorData[] = array(
						'account_number' => $Customer['account_number'],
						'error'=>1,
						'log'=>$Errmsg
					   );
					   $ErrorCnt++;
				}else{
					
					$updatedata[] = array(
						'account_number' => $Customer['account_number'],
						'zone_id' => $ZoneId,
						'province_id' => $ProvinceId
					   );	
					   $UpdateCnt++;
				}
			 }
			 if($UpdateCnt>0){
				$this->Customer_Model->Update_Customer($updatedata);
			 }
			 if($ErrorCnt>0){
				$this->Customer_Model->Update_Customer_tmp($ErrorData);
			 }
	 
	 
		 if($ErrorCnt>0){
			echo 0;
		 }else{
			echo '1';
		 }

		 // insert import data
		 
		
	  }else{ 
		 echo '0';
	  } 
   }


		
		public function create()
		{
			// Check login
			if(!$this->session->userdata('login')) {
				
				redirect('users/login');
			}
			//echo CI_VERSION;exit();
			$data['title'] = 'Create Category';
				$this->load->view('templates/header');
				$this->load->view('templates/sidebar');
				$this->load->view('customer/create', $data);
				$this->load->view('templates/footer');
			
		}

		public function index()
		{
			if(!$this->session->userdata('login')) {
				
				redirect('users/login');
			}
			$data['title'] = 'Customers';

			$data['categories'] = $this->Customer_Model->get_customers();
			//exit();			
			$this->load->view('templates/header');
			$this->load->view('templates/sidebar');
			$this->load->view('customer/index', $data);
			$this->load->view('templates/footer');
		}

		

	
	}