<?php
	class Users extends CI_Controller
	{
	
		// Log in User
		public function login(){
			$data['title'] = 'Sign In';

			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');
//var_dump($this->form_validation->run());exit();
			if($this->form_validation->run() === FALSE){
				//$this->load->view('templates/header');
				$this->load->view('users/login', $data);
				//$this->load->view('templates/footer');
			}else{
				// get username and Encrypt Password
				$username = $this->input->post('username');
				$password = $this->input->post('password');
				

				$user_id = $this->User_Model->login($username, $password);
				//var_dump($user_id);exit();
				if ($user_id) {
					//Create Session
					$user_data = array(
								'user_id' => $user_id->id,
				 				'username' => $username,
				 				'email' => $user_id->email,
				 				'login' => true
				 	);

				 	$this->session->set_userdata($user_data);

					//Set Message
					$this->session->set_flashdata('user_loggedin', 'You are now logged in.');
					redirect('customer');
				}else{
					$this->session->set_flashdata('login_failed', 'Login is invalid.');
					redirect('users/login');
				}
				
			}
		}

		// log user out
		public function logout(){
			// unset user data
			$this->session->unset_userdata('login');
			$this->session->unset_userdata('user_id');
			$this->session->unset_userdata('username');

			//Set Message
			$this->session->set_flashdata('user_loggedout', 'You are logged out.');
			redirect(base_url());
		}

		
	}