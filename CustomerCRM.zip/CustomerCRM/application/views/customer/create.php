<link rel="stylesheet" href="<?php echo base_url();?>assets/alert/sweetalert.css">  
<script src="<?php echo base_url();?>assets/alert/sweetalert-dev.js"></script>
<script src="<?php echo base_url();?>assets/alert/sweetalert2@11.js"></script>


        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
		  <?php echo validation_errors(); ?>
           <?php echo form_open_multipart('team/create'); ?>
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Upload Records</h4>
                     <?php if($this->session->flashdata('Duplicate_TeamName')): ?>
      <?php echo '<p class="alert alert-danger">'.$this->session->flashdata('Duplicate_TeamName').'</p>'; ?>
    <?php endif; ?>
    
                    <form class="forms-sample" enctype='multipart/form-data'>
                      
					                        
					 
            <div class="container" style="
    padding: 0px;
    margin: 0px;
">
            <input type="file" name="file" id="file">

            <!-- Drag and Drop container-->
            <div class="upload-area"  id="uploadfile">
            <div class='Uploadtxt' >  Drag and Drop file here Or Click to select file</div>
            </div>
        </div>

                     <br>
                      
                     <div style="
    text-align: center;
">
                     <button class="btn btn-info" type="button" onclick="fnCancel()">Back</button>
                      <button class="btn btn-danger" type="button" onclick="fnErrorLog()">Error Log</button>
                     </div>
                    </form>
                  </div>
                </div>
              </div>
             
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <script>
	function fnCancel(){
		Base="<?php echo base_url(); ?>";
	window.location=Base+"customer";
	}
  function fnErrorLog(){
    Base="<?php echo base_url(); ?>";
	window.location=Base+"customer/errorlog";
  }
	
	
        
        function uploadData(formdata){

$.ajax({
            
    url: 'import',
    type: 'post',
    data: formdata,
    contentType: false,
    processData: false,
    dataType: 'json',
    success: function(response){
//         addThumbnail(response);
if(response==0){
  Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something went wrong!',
            footer: '<a href="">Please Download the Log</a>'
          })}else{
  Swal.fire({
  title: 'Records Updated Successfully',
  showDenyButton: false,
  showCancelButton: false,
  confirmButtonText: 'OK',
}).then((result) => {
  /* Read more about isConfirmed, isDenied below */
  if (result.isConfirmed) {
  
    Base="<?php echo base_url(); ?>";
	window.location=Base+"customer";
  } else if (result.isDenied) {
   // Swal.fire('Changes are not saved', '', 'info')
  }
})
      
}

                   
      
        
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something went wrong!',
            footer: '<a href="">Please Download the Log</a>'
          })
          
     }
});
}
 
	</script>