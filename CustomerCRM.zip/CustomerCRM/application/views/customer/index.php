
<link rel="stylesheet" href="<?php echo base_url();?>assets/alert/sweetalert.css">  
<script src="<?php echo base_url();?>assets/alert/sweetalert-dev.js"></script>
<script src="<?php echo base_url();?>assets/alert/sweetalert2@11.js"></script>
<style>
th{
  font-weight:bold !important;
}
  
</style>


        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
           
            <div class="row">
              <?php if($this->session->flashdata('Team_created')): ?>
      <?php echo '<p class="alert alert-success">'.$this->session->flashdata('Team_created').'</p>'; ?>
    <?php endif; ?>
              <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>

<!-- jQuery Modal -->
<script src="<?php echo base_url(); ?>assets/js/jquery.modal.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery.modal.min.css" />

<!-- Link to open the modal -->
<p></p>
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">CRM</h4>
                    <button type="submit" class="btn btn-primary mr-2" onclick="fnAddNew()">Upload Records</button>
                    <a class="btn btn-info" type="button" href='upload/sample.csv' download style="
    float: right;
" >Download Sample</a> 
                      
                      <button type="submit" class="btn btn-danger mr-2" onclick="fnClear()" style="
    float: right;
">Clear Data</button>
<br><br>
                    <table class="table table-striped" id="table" style="
    border: 1px solid gray;
">
                      <thead style="
    background-color: gray;
    color: #fff;
">
                        <tr>
                          <th style="    border-bottom: 1px solid gray;"> SNO </th>
                          <th style="    border-bottom: 1px solid gray;"> Account Number</th>
                          <th style="    border-bottom: 1px solid gray;"> Company Name</th>
                          <th style="    border-bottom: 1px solid gray;"> Zone </th>
                          <th style="    border-bottom: 1px solid gray;"> Province </th>
                          <!--th> View </th-->
                        </tr>
                      </thead>
                      <tbody>
					  <?php
					  if(sizeof($categories)==0){
						echo "<tr><td colspan='5' style='text-align:center'>No Records Found</td></tr>";
					  }
					  ?>
					  <?php 
            $Sno=1;
            foreach($categories as $category) : ?>
                        <tr>
                         <td> <?php echo $Sno; $Sno++; ?> </td>
                          <td> <?php echo $category['account_number']; ?> </td>
                          <td> <?php echo $category['company_name']; ?> </td>
                          
                         <td> <?php echo $category['zone_description']; ?> </td>
						 <td> <?php echo $category['province_description']; ?> </td>
                        
						</tr>
                       
                       <?php endforeach; ?>
                      

                       
                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
             
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
           
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
	<script>
	
	function fnAddNew(){
		window.location="customer/add";
	}
  function fnClear(){
    Swal.fire({
  title: 'Are you Sure want to clear Data?',
  showDenyButton: false,
  showCancelButton: true,
  confirmButtonText: 'YES',
}).then((result) => {
  /* Read more about isConfirmed, isDenied below */
  if (result.isConfirmed) {
  
    window.location="customer/cleardata";
  } else if (result.isDenied) {
   // Swal.fire('Changes are not saved', '', 'info')
  }
})
    
  }
	</script>
   