-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2023 at 12:40 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customer_crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `crm_customer`
--

CREATE TABLE `crm_customer` (
  `customer_id` int(10) UNSIGNED NOT NULL,
  `account_number` varchar(6) NOT NULL,
  `trading_entity_type_id` tinyint(3) UNSIGNED NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `company_name_legal` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `suburb` varchar(50) NOT NULL,
  `town` varchar(50) NOT NULL,
  `province_id` tinyint(3) UNSIGNED NOT NULL,
  `country_id` tinyint(3) UNSIGNED NOT NULL,
  `email` varchar(100) NOT NULL,
  `email2` varchar(100) NOT NULL,
  `telephone1` varchar(15) NOT NULL,
  `telephone2` varchar(15) NOT NULL,
  `fax` varchar(15) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `default_credit_limit` decimal(18,2) NOT NULL,
  `default_credit_limit_extended` decimal(18,2) NOT NULL,
  `parent_customer_id` int(11) NOT NULL,
  `customer_postalcode` varchar(8) NOT NULL,
  `customer_pricelist_id` tinyint(3) UNSIGNED NOT NULL,
  `customer_vatnumber` varchar(20) NOT NULL,
  `created_dtm` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `geocode` point NOT NULL,
  `customer_ranking` tinyint(3) UNSIGNED NOT NULL,
  `customer_admin_fee_notes` varchar(50) NOT NULL,
  `customer_status` tinyint(3) UNSIGNED NOT NULL,
  `customer_status_elite` tinyint(3) UNSIGNED NOT NULL,
  `customer_elec_payment` tinyint(3) UNSIGNED NOT NULL,
  `customer_elec_vat` tinyint(4) NOT NULL,
  `enable_airtime` tinyint(1) NOT NULL,
  `enable_elec` tinyint(1) NOT NULL,
  `enable_bill` tinyint(1) NOT NULL,
  `enable_unipin` tinyint(3) UNSIGNED NOT NULL,
  `enable_mamamoney` tinyint(3) UNSIGNED NOT NULL,
  `enable_cashms` tinyint(3) UNSIGNED NOT NULL,
  `updated_dtm` datetime DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  `customer_allow_credit` tinyint(3) UNSIGNED NOT NULL,
  `customer_group_id` tinyint(3) UNSIGNED NOT NULL,
  `user_salesman` int(10) UNSIGNED NOT NULL,
  `user_manager` int(10) UNSIGNED NOT NULL,
  `user_salesagent` int(10) UNSIGNED NOT NULL,
  `demographic` tinyint(4) NOT NULL,
  `paper_pricelist_id` tinyint(4) NOT NULL,
  `paper_free_units` tinyint(3) UNSIGNED NOT NULL,
  `paper_pickup` tinyint(3) UNSIGNED NOT NULL,
  `admin_pricelist_id` tinyint(4) NOT NULL,
  `emergency_desc` varchar(55) NOT NULL,
  `emergency_sms` varchar(55) NOT NULL,
  `admin_fee_notes` varchar(150) NOT NULL,
  `airtime_rebate_vat` tinyint(3) UNSIGNED NOT NULL,
  `airtime_rebate_method_id` tinyint(3) UNSIGNED NOT NULL,
  `payment_point` tinyint(3) UNSIGNED NOT NULL,
  `email_rpt_daily_sales` tinyint(4) NOT NULL,
  `elec_max_sales_value` int(10) UNSIGNED NOT NULL,
  `bill_max_sales_value` int(10) UNSIGNED NOT NULL,
  `adsl_rebate` varchar(100) NOT NULL,
  `adsl_connection` tinyint(3) UNSIGNED NOT NULL,
  `terminal_owned` tinyint(3) UNSIGNED NOT NULL,
  `terminal_amount_paid` varchar(100) NOT NULL,
  `payment_terms` varchar(500) NOT NULL,
  `bank_name` varchar(45) NOT NULL,
  `bank_branch_code` varchar(45) NOT NULL,
  `bank_account_type` varchar(45) NOT NULL,
  `bank_account_number` varchar(45) NOT NULL,
  `email_rpt_fintx_weekly` tinyint(3) UNSIGNED NOT NULL,
  `email_rpt_fintx_monthly` tinyint(3) UNSIGNED NOT NULL,
  `email_rpt_zsummary` tinyint(3) UNSIGNED NOT NULL,
  `bill_rebate_vat` tinyint(3) UNSIGNED NOT NULL,
  `bill_rebate_method_id` tinyint(3) UNSIGNED NOT NULL,
  `customer_balanced` tinyint(3) UNSIGNED NOT NULL,
  `billpayments_pricelist_id` tinyint(3) UNSIGNED NOT NULL,
  `zone_id` tinyint(3) UNSIGNED NOT NULL,
  `zone_order` varchar(10) NOT NULL,
  `customer_category_id` int(10) UNSIGNED NOT NULL,
  `cashup_allow_zero_z` tinyint(3) UNSIGNED NOT NULL,
  `enable_remote_ext_credit` tinyint(3) UNSIGNED NOT NULL,
  `customer_accept_dtm` datetime DEFAULT NULL,
  `payment_terms_admin` varchar(500) NOT NULL,
  `bank_retailer_fee_pricelist_id` tinyint(3) UNSIGNED NOT NULL,
  `spi_catalog_id` tinyint(3) UNSIGNED NOT NULL,
  `english_fluency` tinyint(3) UNSIGNED NOT NULL,
  `manager_name` varchar(45) NOT NULL,
  `manager_contact` varchar(45) NOT NULL,
  `allow_transfer_cash` tinyint(3) UNSIGNED NOT NULL,
  `allow_transfer_interstore` tinyint(3) UNSIGNED NOT NULL,
  `invoice_settlement_day` tinyint(3) UNSIGNED NOT NULL,
  `cashms_dc_id` int(10) UNSIGNED NOT NULL,
  `cashms_acc_number` varchar(15) NOT NULL,
  `cashms_limit` decimal(9,2) NOT NULL,
  `customer_segment` tinyint(3) UNSIGNED NOT NULL,
  `municipal_area` varchar(45) NOT NULL,
  `enable_easyairtime` tinyint(3) UNSIGNED NOT NULL,
  `easyairtime_pricelist_id` tinyint(3) UNSIGNED NOT NULL,
  `unipin_pricelist_id` tinyint(3) UNSIGNED NOT NULL,
  `international_pricelist_id` tinyint(3) UNSIGNED NOT NULL,
  `payat_account_number` char(6) NOT NULL,
  `payat_account_number_cash` char(6) NOT NULL,
  `enable_vas` tinyint(3) UNSIGNED NOT NULL,
  `enable_dstv_std_wallet` tinyint(3) UNSIGNED NOT NULL,
  `enable_rpt_monthly_deposit` tinyint(3) UNSIGNED NOT NULL,
  `enable_rpt_comm_statement` tinyint(3) UNSIGNED NOT NULL,
  `enable_rpt_monthly_sales` tinyint(3) UNSIGNED NOT NULL,
  `mobile_whatsapp` varchar(45) NOT NULL,
  `mobile_whatsapp_disable` tinyint(3) UNSIGNED NOT NULL,
  `pricelist_data_percent` int(10) UNSIGNED NOT NULL,
  `oneforyou_pricelist_id` int(10) UNSIGNED NOT NULL,
  `ott_pricelist_id` int(10) UNSIGNED NOT NULL,
  `enable_international` tinyint(3) UNSIGNED NOT NULL,
  `spotify_pricelist_id` int(10) UNSIGNED NOT NULL,
  `uber_pricelist_id` int(10) UNSIGNED NOT NULL,
  `netflix_pricelist_id` int(10) UNSIGNED NOT NULL,
  `bluvoucher_pricelist_id` int(11) NOT NULL,
  `ringas_pricelist_id` int(11) NOT NULL,
  `enable_ringas` tinyint(4) NOT NULL,
  `enable_bluvoucher` tinyint(4) NOT NULL,
  `enable_ott` tinyint(4) NOT NULL,
  `enable_oneforu` tinyint(4) NOT NULL,
  `bank_branch_name` varchar(150) NOT NULL,
  `bank_account_name` varchar(150) NOT NULL,
  `enable_cash_card` tinyint(4) NOT NULL,
  `fraud` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `crm_customer`
--

INSERT INTO `crm_customer` (`customer_id`, `account_number`, `trading_entity_type_id`, `company_name`, `company_name_legal`, `contact`, `address1`, `address2`, `suburb`, `town`, `province_id`, `country_id`, `email`, `email2`, `telephone1`, `telephone2`, `fax`, `mobile`, `default_credit_limit`, `default_credit_limit_extended`, `parent_customer_id`, `customer_postalcode`, `customer_pricelist_id`, `customer_vatnumber`, `created_dtm`, `geocode`, `customer_ranking`, `customer_admin_fee_notes`, `customer_status`, `customer_status_elite`, `customer_elec_payment`, `customer_elec_vat`, `enable_airtime`, `enable_elec`, `enable_bill`, `enable_unipin`, `enable_mamamoney`, `enable_cashms`, `updated_dtm`, `updated_by`, `customer_allow_credit`, `customer_group_id`, `user_salesman`, `user_manager`, `user_salesagent`, `demographic`, `paper_pricelist_id`, `paper_free_units`, `paper_pickup`, `admin_pricelist_id`, `emergency_desc`, `emergency_sms`, `admin_fee_notes`, `airtime_rebate_vat`, `airtime_rebate_method_id`, `payment_point`, `email_rpt_daily_sales`, `elec_max_sales_value`, `bill_max_sales_value`, `adsl_rebate`, `adsl_connection`, `terminal_owned`, `terminal_amount_paid`, `payment_terms`, `bank_name`, `bank_branch_code`, `bank_account_type`, `bank_account_number`, `email_rpt_fintx_weekly`, `email_rpt_fintx_monthly`, `email_rpt_zsummary`, `bill_rebate_vat`, `bill_rebate_method_id`, `customer_balanced`, `billpayments_pricelist_id`, `zone_id`, `zone_order`, `customer_category_id`, `cashup_allow_zero_z`, `enable_remote_ext_credit`, `customer_accept_dtm`, `payment_terms_admin`, `bank_retailer_fee_pricelist_id`, `spi_catalog_id`, `english_fluency`, `manager_name`, `manager_contact`, `allow_transfer_cash`, `allow_transfer_interstore`, `invoice_settlement_day`, `cashms_dc_id`, `cashms_acc_number`, `cashms_limit`, `customer_segment`, `municipal_area`, `enable_easyairtime`, `easyairtime_pricelist_id`, `unipin_pricelist_id`, `international_pricelist_id`, `payat_account_number`, `payat_account_number_cash`, `enable_vas`, `enable_dstv_std_wallet`, `enable_rpt_monthly_deposit`, `enable_rpt_comm_statement`, `enable_rpt_monthly_sales`, `mobile_whatsapp`, `mobile_whatsapp_disable`, `pricelist_data_percent`, `oneforyou_pricelist_id`, `ott_pricelist_id`, `enable_international`, `spotify_pricelist_id`, `uber_pricelist_id`, `netflix_pricelist_id`, `bluvoucher_pricelist_id`, `ringas_pricelist_id`, `enable_ringas`, `enable_bluvoucher`, `enable_ott`, `enable_oneforu`, `bank_branch_name`, `bank_account_name`, `enable_cash_card`, `fraud`) VALUES
(1, 'MNN897', 0, 'Company1', '', '', '', '', '', '', 0, 0, '', '', '', '', '', '', '0.00', '0.00', 0, '', 0, '', '2023-01-23 10:53:28', 0x, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', 0, 0, 0, 0, 0, 0, '', 0, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, NULL, '', 0, 0, 0, '', '', 0, 0, 0, 0, '', '0.00', 0, '', 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0),
(2, 'PTG999', 0, 'Company2', '', '', '', '', '', '', 0, 0, '', '', '', '', '', '', '0.00', '0.00', 0, '', 0, '', '2023-01-23 10:53:28', 0x, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', 0, 0, 0, 0, 0, 0, '', 0, 0, '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, NULL, '', 0, 0, 0, '', '', 0, 0, 0, 0, '', '0.00', 0, '', 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `crm_ik_zone`
--

CREATE TABLE `crm_ik_zone` (
  `zone_id` int(10) UNSIGNED NOT NULL,
  `zone_description` varchar(255) NOT NULL,
  `zone_location` enum('Office Metro','Office Rural','Office Informal','Metro','Rural','Informal') NOT NULL,
  `province_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `crm_ik_zone`
--

INSERT INTO `crm_ik_zone` (`zone_id`, `zone_description`, `zone_location`, `province_id`) VALUES
(1, 'WC Zone 5', '', 1),
(2, 'WC Zone 1', '', 1),
(3, 'Zone3', '', 1),
(4, 'Zone4', '', 1),
(5, 'Zone5', '', 1),
(6, 'Zone6', '', 1),
(7, 'Zone7', '', 1),
(8, 'Zone8', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `crm_province`
--

CREATE TABLE `crm_province` (
  `province_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `province_description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `crm_province`
--

INSERT INTO `crm_province` (`province_id`, `country_id`, `province_description`) VALUES
(1, 1, 'Western Cape'),
(2, 1, 'Province2'),
(3, 1, 'Province3'),
(4, 1, 'Province4'),
(5, 1, 'Province5'),
(6, 1, 'Province6'),
(7, 1, 'Province7'),
(8, 1, 'Province8');

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer`
-- (See below for the actual view)
--
CREATE TABLE `customer` (
`customer_id` int(10) unsigned
,`account_number` varchar(6)
,`company_name` varchar(50)
,`zone_description` varchar(255)
,`province_description` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `temp_customer`
--

CREATE TABLE `temp_customer` (
  `id` int(11) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `zone` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `error` int(11) NOT NULL,
  `log` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `temp_customer`
--

INSERT INTO `temp_customer` (`id`, `account_number`, `zone`, `province`, `error`, `log`) VALUES
(1, 'MNN897', 'WC Zone 1 - Manenberg, Heideveld,Bonteheuwel, Hazendal, Sybrand Park, Athlone, Gatesville, Rylands, Hanover Park, Newfields', 'Western Cape', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `tm_user`
--

CREATE TABLE `tm_user` (
  `UserId` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `RecStatus` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tm_user`
--

INSERT INTO `tm_user` (`UserId`, `UserName`, `Password`, `RecStatus`) VALUES
(1, 'admin', 'admin', 1);

-- --------------------------------------------------------

--
-- Structure for view `customer`
--
DROP TABLE IF EXISTS `customer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer`  AS SELECT `a`.`customer_id` AS `customer_id`, `a`.`account_number` AS `account_number`, `a`.`company_name` AS `company_name`, `b`.`zone_description` AS `zone_description`, `c`.`province_description` AS `province_description` FROM ((`crm_customer` `a` left join `crm_ik_zone` `b` on(`a`.`zone_id` = `b`.`zone_id`)) left join `crm_province` `c` on(`a`.`province_id` = `c`.`province_id`))  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crm_customer`
--
ALTER TABLE `crm_customer`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `account_number` (`account_number`);

--
-- Indexes for table `crm_ik_zone`
--
ALTER TABLE `crm_ik_zone`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `crm_province`
--
ALTER TABLE `crm_province`
  ADD PRIMARY KEY (`province_id`);

--
-- Indexes for table `temp_customer`
--
ALTER TABLE `temp_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tm_user`
--
ALTER TABLE `tm_user`
  ADD PRIMARY KEY (`UserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crm_customer`
--
ALTER TABLE `crm_customer`
  MODIFY `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `crm_ik_zone`
--
ALTER TABLE `crm_ik_zone`
  MODIFY `zone_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `crm_province`
--
ALTER TABLE `crm_province`
  MODIFY `province_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `temp_customer`
--
ALTER TABLE `temp_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tm_user`
--
ALTER TABLE `tm_user`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
